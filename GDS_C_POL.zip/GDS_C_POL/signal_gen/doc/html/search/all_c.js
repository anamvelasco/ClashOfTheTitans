var searchData=
[
  ['todo_0',['ToDo',['../index.html#todo',1,'']]],
  ['triangular_1',['TRIANGULAR',['../main_8c.html#a7d8c79438df26f5d08937a6566cd8ddfabf52229ee9b3785c253ecf6466ce14b8',1,'main.c']]]
];
