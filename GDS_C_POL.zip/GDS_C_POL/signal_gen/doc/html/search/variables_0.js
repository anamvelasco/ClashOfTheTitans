var searchData=
[
  ['amplitude_0',['amplitude',['../main_8c.html#a31bef58f966d97b1ace9bd3a58ffd9a6',1,'main.c']]]
];
