var searchData=
[
  ['dacpins_0',['dacPins',['../main_8c.html#a0c0ddceb5a6154edc520f9b8a2e25cb6',1,'main.c']]],
  ['dcoffset_1',['dcOffset',['../main_8c.html#a258b14a581f0fc4211829f7ad0282ad3',1,'main.c']]]
];
