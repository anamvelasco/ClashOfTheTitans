var searchData=
[
  ['amplitude_5fdefault_0',['AMPLITUDE_DEFAULT',['../main_8c.html#a26e92d4e12084135bbab16a41784946b',1,'main.c']]],
  ['amplitude_5fmax_1',['AMPLITUDE_MAX',['../main_8c.html#a225ca4481cc8bc065f82db955b3058ef',1,'main.c']]],
  ['amplitude_5fmax_5fdac_2',['AMPLITUDE_MAX_DAC',['../main_8c.html#aa963f47df97c0fb894e23c92d030f7b9',1,'main.c']]],
  ['amplitude_5fmin_3',['AMPLITUDE_MIN',['../main_8c.html#a67a5f231b52df2f8cc2af35609cbd376',1,'main.c']]]
];
