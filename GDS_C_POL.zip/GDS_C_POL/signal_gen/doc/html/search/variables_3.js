var searchData=
[
  ['frequency_0',['frequency',['../main_8c.html#acdfc8898c9e67fbcec81f3b04ae61bd9',1,'main.c']]]
];
