var searchData=
[
  ['frequency_0',['frequency',['../main_8c.html#a40f530119a7aefd258a648a199341686',1,'main.c']]],
  ['frequency_5fmax_1',['FREQUENCY_MAX',['../main_8c.html#a723455414fa26047e35c5e96c09ccf0c',1,'main.c']]],
  ['frequency_5fmin_2',['FREQUENCY_MIN',['../main_8c.html#aab1126a23f72e0d2b7e271f19ee330ba',1,'main.c']]]
];
