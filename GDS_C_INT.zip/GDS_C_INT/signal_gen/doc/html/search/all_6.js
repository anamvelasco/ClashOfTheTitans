var searchData=
[
  ['generador_20de_20señales_20digital_20con_20interrupciones_20y_20teclado_20matricial_0',['Generador de Señales Digital con Interrupciones y Teclado Matricial',['../index.html',1,'']]],
  ['generate_5fwaveform_1',['generate_waveform',['../main_8c.html#a1741995211c26b56c6974c10a1ddd410',1,'main.c']]],
  ['gpio_5fcallback_2',['gpio_callback',['../main_8c.html#a7f6538b252b233c2a00eeabf455b6ac8',1,'main.c']]]
];
