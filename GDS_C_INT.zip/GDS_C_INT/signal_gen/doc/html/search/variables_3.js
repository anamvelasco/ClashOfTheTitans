var searchData=
[
  ['frequency_0',['frequency',['../main_8c.html#a40f530119a7aefd258a648a199341686',1,'main.c']]]
];
