var searchData=
[
  ['colpins_0',['colPins',['../main_8c.html#a1de16f317864994318321193fcfa135d',1,'main.c']]],
  ['current_5fwaveform_1',['current_waveform',['../main_8c.html#a3304bb90581ab3d37b30a65af3d098f5',1,'main.c']]]
];
