var searchData=
[
  ['amplitude_5fmax_0',['AMPLITUDE_MAX',['../main_8c.html#a225ca4481cc8bc065f82db955b3058ef',1,'main.c']]],
  ['amplitude_5fmin_1',['AMPLITUDE_MIN',['../main_8c.html#a67a5f231b52df2f8cc2af35609cbd376',1,'main.c']]],
  ['architecture_5fid_2',['ARCHITECTURE_ID',['../_c_make_c_compiler_id_8c.html#aba35d0d200deaeb06aee95ca297acb28',1,'ARCHITECTURE_ID:&#160;CMakeCCompilerId.c'],['../_c_make_c_x_x_compiler_id_8cpp.html#aba35d0d200deaeb06aee95ca297acb28',1,'ARCHITECTURE_ID:&#160;CMakeCXXCompilerId.cpp']]]
];
