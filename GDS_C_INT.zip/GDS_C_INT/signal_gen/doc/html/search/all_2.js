var searchData=
[
  ['bibliotecas_0',['Bibliotecas',['../index.html#libraries',1,'']]]
];
