var searchData=
[
  ['dc_5foffset_0',['dc_offset',['../main_8c.html#a0e809c8840905e1882aca5de814d67c9',1,'main.c']]]
];
