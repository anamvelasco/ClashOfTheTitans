var searchData=
[
  ['amplitude_0',['amplitude',['../main_8c.html#aab9449dcb5f496c556d5e32b4d25b7f8',1,'main.c']]]
];
