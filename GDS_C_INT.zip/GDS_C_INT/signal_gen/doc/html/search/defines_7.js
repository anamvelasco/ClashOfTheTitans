var searchData=
[
  ['pico_5fsdk_5fversion_5fmajor_0',['PICO_SDK_VERSION_MAJOR',['../version_8h.html#a389b2ab6feac8cb2e16cc15c2355b1a9',1,'version.h']]],
  ['pico_5fsdk_5fversion_5fminor_1',['PICO_SDK_VERSION_MINOR',['../version_8h.html#a2dda83706b2cefcf15dfdbc278676c0f',1,'version.h']]],
  ['pico_5fsdk_5fversion_5frevision_2',['PICO_SDK_VERSION_REVISION',['../version_8h.html#a5be32caa1531cc592aeff17e4c5b230d',1,'version.h']]],
  ['pico_5fsdk_5fversion_5fstring_3',['PICO_SDK_VERSION_STRING',['../version_8h.html#a335c1eae5c5da86063f72343c92764db',1,'version.h']]],
  ['platform_5fid_4',['PLATFORM_ID',['../_c_make_c_compiler_id_8c.html#adbc5372f40838899018fadbc89bd588b',1,'PLATFORM_ID:&#160;CMakeCCompilerId.c'],['../_c_make_c_x_x_compiler_id_8cpp.html#adbc5372f40838899018fadbc89bd588b',1,'PLATFORM_ID:&#160;CMakeCXXCompilerId.cpp']]]
];
