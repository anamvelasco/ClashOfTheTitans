var searchData=
[
  ['hacer_0',['Por hacer',['../index.html#todo',1,'']]],
  ['handle_5finput_1',['handle_input',['../main_8c.html#a44309b0eb64f8974cd1e9615c26cb98c',1,'main.c']]]
];
