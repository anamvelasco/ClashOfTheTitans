var searchData=
[
  ['amplitude_5fmax_0',['AMPLITUDE_MAX',['../main_8c.html#a225ca4481cc8bc065f82db955b3058ef',1,'main.c']]],
  ['amplitude_5fmin_1',['AMPLITUDE_MIN',['../main_8c.html#a67a5f231b52df2f8cc2af35609cbd376',1,'main.c']]]
];
