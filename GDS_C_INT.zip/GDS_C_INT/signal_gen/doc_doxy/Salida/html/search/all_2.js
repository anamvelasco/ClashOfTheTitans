var searchData=
[
  ['circuito_0',['Circuito',['../index.html#circuit',1,'']]],
  ['colpins_1',['colPins',['../main_8c.html#a1de16f317864994318321193fcfa135d',1,'main.c']]],
  ['cols_2',['COLS',['../main_8c.html#ab59ad2ee1a48b83c2eef1f019ed8cc48',1,'main.c']]],
  ['con_20interrupciones_20y_20teclado_20matricial_3',['Generador de SeÃ±ales Digital con Interrupciones y Teclado Matricial',['../index.html',1,'']]],
  ['copyright_4',['Copyright',['../index.html#copyright',1,'']]],
  ['current_5fwaveform_5',['current_waveform',['../main_8c.html#a3304bb90581ab3d37b30a65af3d098f5',1,'main.c']]]
];
