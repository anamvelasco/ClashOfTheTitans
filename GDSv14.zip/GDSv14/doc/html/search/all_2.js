var searchData=
[
  ['dacpins_0',['dacPins',['../_g_d_sv14_8ino.html#a2110a36ca4a2a096f4546aba11e025d7',1,'GDSv14.ino']]],
  ['dcoffset_1',['dcOffset',['../_g_d_sv14_8ino.html#a258b14a581f0fc4211829f7ad0282ad3',1,'GDSv14.ino']]],
  ['description_2',['Description',['../index.html#description',1,'']]]
];
