var searchData=
[
  ['sawtooth_0',['SAWTOOTH',['../_g_d_sv14_8ino.html#a7d8c79438df26f5d08937a6566cd8ddfa40e63a8384df5217cf58feeb37aa7e96',1,'GDSv14.ino']]],
  ['setup_1',['setup',['../_g_d_sv14_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'GDSv14.ino']]],
  ['setup_5fgpio_2',['setup_gpio',['../_g_d_sv14_8ino.html#acee10fb61031896f1d6682326b0c29fb',1,'GDSv14.ino']]],
  ['signal_20generator_20project_3',['Signal Generator Project',['../index.html',1,'']]],
  ['sine_4',['SINE',['../_g_d_sv14_8ino.html#a7d8c79438df26f5d08937a6566cd8ddfa6fb78345b237d9715b391bff6773e931',1,'GDSv14.ino']]],
  ['square_5',['SQUARE',['../_g_d_sv14_8ino.html#a7d8c79438df26f5d08937a6566cd8ddfa4233fbf0cafb86abcee94b38d769fc59',1,'GDSv14.ino']]]
];
