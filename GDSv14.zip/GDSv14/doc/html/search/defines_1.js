var searchData=
[
  ['frequency_5fmax_0',['FREQUENCY_MAX',['../_g_d_sv14_8ino.html#a723455414fa26047e35c5e96c09ccf0c',1,'GDSv14.ino']]],
  ['frequency_5fmin_1',['FREQUENCY_MIN',['../_g_d_sv14_8ino.html#aab1126a23f72e0d2b7e271f19ee330ba',1,'GDSv14.ino']]]
];
