var searchData=
[
  ['waveform_0',['Waveform',['../_g_d_sv14_8ino.html#a7d8c79438df26f5d08937a6566cd8ddf',1,'GDSv14.ino']]]
];
