var searchData=
[
  ['setup_0',['setup',['../_g_d_sv14_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'GDSv14.ino']]],
  ['setup_5fgpio_1',['setup_gpio',['../_g_d_sv14_8ino.html#acee10fb61031896f1d6682326b0c29fb',1,'GDSv14.ino']]]
];
