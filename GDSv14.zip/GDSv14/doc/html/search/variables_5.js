var searchData=
[
  ['rowpins_0',['rowPins',['../_g_d_sv14_8ino.html#a6d6753e0ae098b31e2f84d4024e361cf',1,'GDSv14.ino']]],
  ['rows_1',['ROWS',['../_g_d_sv14_8ino.html#a829655a147df70dd4cc94eae40a2204e',1,'GDSv14.ino']]]
];
