var searchData=
[
  ['readamplitude_0',['readAmplitude',['../_g_d_sv14_8ino.html#ae610ec980bd3ef60b0bc64d51e2a5fa0',1,'GDSv14.ino']]],
  ['readdcoffset_1',['readDCOffset',['../_g_d_sv14_8ino.html#aaab1cb61f66f14594caec2d65625ffc2',1,'GDSv14.ino']]],
  ['readfrequency_2',['readFrequency',['../_g_d_sv14_8ino.html#a5643ca3168c803f9a929b5ef94fc06be',1,'GDSv14.ino']]]
];
