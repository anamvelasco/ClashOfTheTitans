var searchData=
[
  ['sawtooth_0',['SAWTOOTH',['../_g_d_sv14_8ino.html#a7d8c79438df26f5d08937a6566cd8ddfa40e63a8384df5217cf58feeb37aa7e96',1,'GDSv14.ino']]],
  ['sine_1',['SINE',['../_g_d_sv14_8ino.html#a7d8c79438df26f5d08937a6566cd8ddfa6fb78345b237d9715b391bff6773e931',1,'GDSv14.ino']]],
  ['square_2',['SQUARE',['../_g_d_sv14_8ino.html#a7d8c79438df26f5d08937a6566cd8ddfa4233fbf0cafb86abcee94b38d769fc59',1,'GDSv14.ino']]]
];
