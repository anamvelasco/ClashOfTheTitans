var searchData=
[
  ['amplitude_0',['amplitude',['../_g_d_sv14_8ino.html#a31bef58f966d97b1ace9bd3a58ffd9a6',1,'GDSv14.ino']]]
];
