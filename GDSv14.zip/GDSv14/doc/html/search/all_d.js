var searchData=
[
  ['waveform_0',['Waveform',['../_g_d_sv14_8ino.html#a7d8c79438df26f5d08937a6566cd8ddf',1,'GDSv14.ino']]],
  ['waveformbuttonpin_1',['waveformButtonPin',['../_g_d_sv14_8ino.html#a549d6107ad3322032b7909297cce93b6',1,'GDSv14.ino']]],
  ['write_5fdac_2',['write_dac',['../_g_d_sv14_8ino.html#a8e63ad2c76e0ccd57a6da11b8d088945',1,'GDSv14.ino']]]
];
