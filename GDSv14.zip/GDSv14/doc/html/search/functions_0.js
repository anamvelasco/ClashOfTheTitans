var searchData=
[
  ['calculatesamplingparameters_0',['calculateSamplingParameters',['../_g_d_sv14_8ino.html#add456fe0fc33f75fdf387e402a2af9b3',1,'GDSv14.ino']]],
  ['changewaveform_1',['changeWaveform',['../_g_d_sv14_8ino.html#a2d3376bf8da7d740624a4a202d17bb42',1,'GDSv14.ino']]]
];
