var searchData=
[
  ['colpins_0',['colPins',['../_g_d_sv14_8ino.html#aa9fece7b062124080e4b2976f9a8b675',1,'GDSv14.ino']]],
  ['cols_1',['COLS',['../_g_d_sv14_8ino.html#aefd90f1160eaa105bc910d4d7c46b815',1,'GDSv14.ino']]],
  ['currentwaveform_2',['currentWaveform',['../_g_d_sv14_8ino.html#a08fb7f43b447a19b458f565c41666bf6',1,'GDSv14.ino']]]
];
