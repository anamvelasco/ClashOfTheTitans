var searchData=
[
  ['amplitude_0',['amplitude',['../_g_d_sv14_8ino.html#a31bef58f966d97b1ace9bd3a58ffd9a6',1,'GDSv14.ino']]],
  ['amplitude_5fdefault_1',['AMPLITUDE_DEFAULT',['../_g_d_sv14_8ino.html#a26e92d4e12084135bbab16a41784946b',1,'GDSv14.ino']]],
  ['amplitude_5fmax_2',['AMPLITUDE_MAX',['../_g_d_sv14_8ino.html#a225ca4481cc8bc065f82db955b3058ef',1,'GDSv14.ino']]],
  ['amplitude_5fmax_5fdac_3',['AMPLITUDE_MAX_DAC',['../_g_d_sv14_8ino.html#aa963f47df97c0fb894e23c92d030f7b9',1,'GDSv14.ino']]],
  ['amplitude_5fmin_4',['AMPLITUDE_MIN',['../_g_d_sv14_8ino.html#a67a5f231b52df2f8cc2af35609cbd376',1,'GDSv14.ino']]],
  ['authors_5',['Authors',['../index.html#author',1,'']]]
];
