var searchData=
[
  ['triangular_0',['TRIANGULAR',['../_g_d_sv14_8ino.html#a7d8c79438df26f5d08937a6566cd8ddfabf52229ee9b3785c253ecf6466ce14b8',1,'GDSv14.ino']]]
];
