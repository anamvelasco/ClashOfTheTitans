var searchData=
[
  ['frequency_0',['frequency',['../_g_d_sv14_8ino.html#acdfc8898c9e67fbcec81f3b04ae61bd9',1,'GDSv14.ino']]]
];
