var searchData=
[
  ['calculatesamplingparameters_0',['calculateSamplingParameters',['../_g_d_sv14_8ino.html#add456fe0fc33f75fdf387e402a2af9b3',1,'GDSv14.ino']]],
  ['changewaveform_1',['changeWaveform',['../_g_d_sv14_8ino.html#a2d3376bf8da7d740624a4a202d17bb42',1,'GDSv14.ino']]],
  ['circuit_2',['Circuit',['../index.html#circuit',1,'']]],
  ['colpins_3',['colPins',['../_g_d_sv14_8ino.html#aa9fece7b062124080e4b2976f9a8b675',1,'GDSv14.ino']]],
  ['cols_4',['COLS',['../_g_d_sv14_8ino.html#aefd90f1160eaa105bc910d4d7c46b815',1,'GDSv14.ino']]],
  ['currentwaveform_5',['currentWaveform',['../_g_d_sv14_8ino.html#a08fb7f43b447a19b458f565c41666bf6',1,'GDSv14.ino']]]
];
