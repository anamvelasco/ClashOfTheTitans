var searchData=
[
  ['setup_0',['setup',['../main_8c.html#a4fc01d736fe50cf5b977f755b675f11d',1,'main.c']]],
  ['setup_5fgpio_1',['setup_gpio',['../main_8c.html#acee10fb61031896f1d6682326b0c29fb',1,'main.c']]]
];
