var searchData=
[
  ['readamplitude_0',['readAmplitude',['../main_8c.html#ae610ec980bd3ef60b0bc64d51e2a5fa0',1,'main.c']]],
  ['readdcoffset_1',['readDCOffset',['../main_8c.html#aaab1cb61f66f14594caec2d65625ffc2',1,'main.c']]],
  ['readfrequency_2',['readFrequency',['../main_8c.html#a5643ca3168c803f9a929b5ef94fc06be',1,'main.c']]],
  ['rowpins_3',['rowPins',['../main_8c.html#ab3985f14b173986c16ce5517148f5cfb',1,'main.c']]],
  ['rows_4',['ROWS',['../main_8c.html#a3cfd3aa62338d12609f6d65bce97e9cd',1,'main.c']]]
];
