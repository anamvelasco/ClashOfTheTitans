var searchData=
[
  ['readamplitude_0',['readAmplitude',['../main_8c.html#ae610ec980bd3ef60b0bc64d51e2a5fa0',1,'main.c']]],
  ['readdcoffset_1',['readDCOffset',['../main_8c.html#aaab1cb61f66f14594caec2d65625ffc2',1,'main.c']]],
  ['readfrequency_2',['readFrequency',['../main_8c.html#a5643ca3168c803f9a929b5ef94fc06be',1,'main.c']]]
];
