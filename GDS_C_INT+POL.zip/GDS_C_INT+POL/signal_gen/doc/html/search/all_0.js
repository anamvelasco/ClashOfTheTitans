var searchData=
[
  ['amplitude_0',['amplitude',['../main_8c.html#a31bef58f966d97b1ace9bd3a58ffd9a6',1,'main.c']]],
  ['amplitude_5fdefault_1',['AMPLITUDE_DEFAULT',['../main_8c.html#a26e92d4e12084135bbab16a41784946b',1,'main.c']]],
  ['amplitude_5fmax_2',['AMPLITUDE_MAX',['../main_8c.html#a225ca4481cc8bc065f82db955b3058ef',1,'main.c']]],
  ['amplitude_5fmax_5fdac_3',['AMPLITUDE_MAX_DAC',['../main_8c.html#aa963f47df97c0fb894e23c92d030f7b9',1,'main.c']]],
  ['amplitude_5fmin_4',['AMPLITUDE_MIN',['../main_8c.html#a67a5f231b52df2f8cc2af35609cbd376',1,'main.c']]],
  ['authors_5',['Authors',['../index.html#author',1,'']]]
];
