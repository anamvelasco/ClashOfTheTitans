var searchData=
[
  ['changewaveform_0',['changeWaveform',['../main_8c.html#a2d3376bf8da7d740624a4a202d17bb42',1,'main.c']]],
  ['circuit_1',['Circuit',['../index.html#circuit',1,'']]],
  ['colpins_2',['colPins',['../main_8c.html#a1de16f317864994318321193fcfa135d',1,'main.c']]],
  ['cols_3',['COLS',['../main_8c.html#ab59ad2ee1a48b83c2eef1f019ed8cc48',1,'main.c']]],
  ['currentwaveform_4',['currentWaveform',['../main_8c.html#a08fb7f43b447a19b458f565c41666bf6',1,'main.c']]]
];
