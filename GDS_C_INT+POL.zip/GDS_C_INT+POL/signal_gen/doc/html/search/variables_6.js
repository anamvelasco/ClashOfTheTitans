var searchData=
[
  ['lastbuttonpresstime_0',['lastButtonPressTime',['../main_8c.html#aebb61b05e23d32ab8ecc0c7005f006fe',1,'main.c']]]
];
