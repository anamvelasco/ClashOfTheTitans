var searchData=
[
  ['colpins_0',['colPins',['../main_8c.html#a1de16f317864994318321193fcfa135d',1,'main.c']]],
  ['currentwaveform_1',['currentWaveform',['../main_8c.html#a08fb7f43b447a19b458f565c41666bf6',1,'main.c']]]
];
